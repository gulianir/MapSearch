### HW9 Feedback

**CSE 331 17sp**

**Name:** <student name> (gulianir)

**Graded By:** <Stephanie Yuan> (<jingyy3@cs.washington.edu)

### Score: 50/50
---

- comment

